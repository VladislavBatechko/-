$(document).ready(function() {

    // модальное окно

    $('#exampleModal').on('show.bs.modal', function(event) {
        var button = $(event.relatedTarget)
        var recipient = button.data('whatever')
        var modal = $(this)
        modal.find('.modal-title').text('New message to ' + recipient)
        modal.find('.modal-body input').val(recipient)
    })



    // таб по таблице

    $('.table-wrapper').hide();
    // Дополнительные опции
    $('.active-btn .option-tab').click(function() {
        $('.green-table').hide();
        $('.active-btn .option-tab').removeClass('active').eq($(this).index()).addClass('');
        $('.table-wrapper').hide().eq($(this).index()).fadeIn();
        $('.active-btn').hide();
    });
    // Прайс-лист
    $('.price-active .price-tab').click(function() {
        $('.table-wrapper-hover').hide();
        $('.price-active .price-tab').removeClass('active').eq($(this).index()).addClass('');
        $('.green-table').hide().eq($(this).index()).fadeIn();
        $('.active-btn').show();
    });



    // таб в Этапах работы

    $('.tab-item').hide();
    $('.tab-text').hide();

    $('.wrapper .tab').click(function() {
        $('.wrapper .tab').removeClass('active').eq($(this).index()).addClass('active');
        $('.tab-text').hide().eq($(this).index()).fadeIn();
        $('.tab-item').hide().eq($(this).index()).fadeIn();
    }).eq().addClass('active');



    // слайдер


    $('.multiple-items').slick({
        infinite: true,
        slidesToShow: 4,
        slidesToScroll: 4,
        arrows: true,
    });

})